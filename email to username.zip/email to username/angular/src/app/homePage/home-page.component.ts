import { Component, OnInit } from '@angular/core';
import { User } from '../users/user/userInterface';
import { Profile } from '../profiles/profile/profileInterface';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { CapBookServicesService } from '../services/cap-book-services.service';

@Component({
  selector: 'app-home-page',
  templateUrl: './home-page.component.html',
  styleUrls: ['./home-page.component.css']
})
export class HomePageComponent implements OnInit {

  pageTitle="Welcome!";
  error: string;
  flag: string='zero';
  user: User = {
    userName: "",
    password: "",
    profile: {
              name: "",
              gender: "",
              phoneNo: "",
              dateOfBirth: "", 
              bio: "",
              emailId: ""
            }
  }
  user1: User = {
    userName: "",
    password: "",
    profile: {
              name: "",
              gender: "",
              phoneNo: "",
              dateOfBirth: "", 
              bio: "",
              emailId: ""
            }
  }
  profileList: Profile[];

  constructor(private route:ActivatedRoute,private router:Router, private httpClient: HttpClient, private capBookService: CapBookServicesService) { }

  ngOnInit() {
    const _user=this.route.snapshot.paramMap.get('userName');
    //const productId= +id;
    this.capBookService.getUserDetails(_user).subscribe(
      user=>{
      this.user=user;
    },
    errorMessage=>{
      this.error=errorMessage;
    })    

    const _user1=this.route.snapshot.paramMap.get('emailId');
    //const productId= +id;
    this.capBookService.getProfileDetails(_user1).subscribe(
      profile1=>{
      this.user.profile=profile1;
    },
    errorMessage=>{
      this.error=errorMessage;
    }) 

  }
  public viewProfile():void{
    if(this.user.profile.name!=null)
    this.router.navigate(['/profile',{"userName":this.user.userName}])
  }
  public goToHome():void{
    if(this.user.profile.name!=null)
    this.router.navigate(['/homePage',{"emailId":this.user.profile.emailId}])
  }

  public searchFriend():any{
    if(this.user1.profile.name!=''){
      this.capBookService.searchFriend(this.user1.profile.name).subscribe(profileList1 => {
        this.profileList = profileList1;
        if(this.profileList.length!=0){
          this.flag='zero';
          this.router.navigate(['/homePage'])
        }
        else{
          this.flag='one';
          this.error="No user with this name";
        }
      },
      errorMessage=>{
        // this.flag='one';
        //this.error="No user with this name";
      });
    }
  }

}
