import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { UsersComponent } from './users/users.component';
import { HttpClientModule } from '@angular/common/http';
import { SignUpUserComponent } from './users/sign-up-user/sign-up-user.component';
import { RouterModule } from '@angular/router';
import { ProfilesComponent } from './profiles/profiles.component';
import { WelcomeComponent } from './welcome/welcome.component';
import { LoginUserComponent } from './users/login-user/login-user.component';
import { HomePageComponent } from './homePage/home-page.component';

@NgModule({
  declarations: [
    AppComponent,
    UsersComponent,
    SignUpUserComponent,
    ProfilesComponent,
    WelcomeComponent,
    LoginUserComponent,
    HomePageComponent,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot([
      { path:'homePage',component: HomePageComponent},
      { path:'profile',component: ProfilesComponent},
      { path:'profile/:emailId',component: ProfilesComponent},
      { path:'signup',component: SignUpUserComponent},
      { path:'login',component: LoginUserComponent},
      { path: 'welcome',component:  WelcomeComponent},
      { path: '',redirectTo:'welcome',pathMatch:'full'}
    ])
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
