import { Profile } from "src/app/profiles/profile/profileInterface";

export interface User{
    userName: string;
    password: string;
    profile: Profile;
}