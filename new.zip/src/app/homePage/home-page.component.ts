import { Component, OnInit } from '@angular/core';
import { User } from '../users/user/userInterface';
import { Profile } from '../profiles/profile/profileInterface';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { CapBookServicesService } from '../services/cap-book-services.service';

@Component({
  selector: 'app-home-page',
  templateUrl: './home-page.component.html',
  styleUrls: ['./home-page.component.css']
})
export class HomePageComponent implements OnInit {

  pageTitle="Welcome!";
  error: string;
  user: User = {
    userName: "",
    password: "",
    profile: {
              name: "",
              gender: "",
              phoneNo: "",
              dateOfBirth: "", 
              bio: "",
              emailId: ""
            }
  }
  constructor(private route:ActivatedRoute,private router:Router, private httpClient: HttpClient, private capBookService: CapBookServicesService) { }

  ngOnInit() {
    const _user=this.route.snapshot.paramMap.get('userName');
    //const productId= +id;
    this.capBookService.getUserDetails(_user).subscribe(
      user=>{
      this.user=user;
    },
    errorMessage=>{
      this.error=errorMessage;
    })    
  }

}
