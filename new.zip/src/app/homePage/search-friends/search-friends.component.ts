import { Component, OnInit } from '@angular/core';
import { User } from 'src/app/users/user/userInterface';
import { Profile } from 'src/app/profiles/profile/profileInterface';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { CapBookServicesService } from 'src/app/services/cap-book-services.service';

@Component({
  selector: 'app-search-friends',
  templateUrl: './search-friends.component.html',
  styleUrls: ['./search-friends.component.css']
})
export class SearchFriendsComponent implements OnInit {

  searchBox:string="Search Box";
  user: User;
  profile: Profile;
  profileList: Profile[];
  error: string;
  constructor(private route:ActivatedRoute,private router:Router, private httpClient: HttpClient, private capBookService: CapBookServicesService) { }

  
  ngOnInit() {
  }

  // public navigateBack():void{
  //   this.router.navigate(['/welcome'])
  // }
  public searchFriend():any{
    this.capBookService.searchFriend(this.profile.name).subscribe(profileList1 => {
      this.profileList = profileList1;
      if(this.profileList!=null)
      this.router.navigate(['/showFriends'])
    },
    errorMessage=>{
      this.error="Please enter correct Details";
    });
  }

}
