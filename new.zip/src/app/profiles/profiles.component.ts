import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profiles',
  templateUrl: './profiles.component.html',
  styleUrls: ['./profiles.component.css']
})
export class ProfilesComponent implements OnInit {
  _name: string;
  _emailId: string;
  _dateOfBirth: string;
  _gender: string;
  _phoneNo: string;

  get emailId():string{
    return this._emailId;
  }
  set emailId(value:string){
    this._emailId=value;
  }
  get dateOfBirth():string{
    return this._dateOfBirth;
  }
  set dateOfBirth(value:string){
    this._dateOfBirth=value;
  }
  get gender():string{
    return this._gender;
  }
  set gender(value:string){
    this._gender=value;
  }
  get phoneNo():string{
    return this._phoneNo;
  }
  set phoneNo(value:string){
    this._phoneNo=value;
  }

  constructor() { }

  ngOnInit() {
  }

}
