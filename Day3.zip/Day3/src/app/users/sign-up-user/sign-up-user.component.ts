import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient, HttpErrorResponse, HttpParams, HttpHeaders } from '@angular/common/http';
import { NgForm } from '@angular/forms';
import { CapBookServicesService } from 'src/app/services/cap-book-services.service';
import { User } from '../user/userInterface';
import { Profile } from 'src/app/profiles/profile/profileInterface';

@Component({
  selector: 'app-sign-up-user',
  templateUrl: './sign-up-user.component.html',
  styleUrls: ['./sign-up-user.component.css']
})
export class SignUpUserComponent implements OnInit {
  pageTitle="Enter Details";
  error: string;
  constructor(private route:ActivatedRoute,private router:Router, private httpClient: HttpClient, private capBookService: CapBookServicesService) { }
   _userName: string;
   _password: string;
   _profile: Profile;

   user: User = {
                userName: "",
                password: "",
                profile: {
                          name: "",
                          gender: "",
                          phoneNo: "",
                          dateOfBirth: "", 
                          bio: "",
                          emailId: ""
                        }
              }

  ngOnInit() {
  }
  public navigateBack():void{
    this.router.navigate(['/welcome'])
  }
  public signUpUser(myForm: NgForm):any{
    this.capBookService.signUpUser(this.user).subscribe(user1 => {
      this.user = user1;
    },
    errorMessage=>{
      this.error=errorMessage;
    });
    this.router.navigate(['/homePage',{"userName":this.user.userName}])
  }
}

