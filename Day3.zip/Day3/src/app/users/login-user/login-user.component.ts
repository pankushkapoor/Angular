import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { CapBookServicesService } from 'src/app/services/cap-book-services.service';
import { User } from '../user/userInterface';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-login-user',
  templateUrl: './login-user.component.html',
  styleUrls: ['./login-user.component.css']
})
export class LoginUserComponent implements OnInit {

  pageTitle="Enter Details";
  error: string;
  user: User = {
    userName: "",
    password: "",
    profile: {
              name: "",
              gender: "",
              phoneNo: "",
              dateOfBirth: "", 
              bio: "",
              emailId: ""
            }
  }
  constructor(private route:ActivatedRoute,private router:Router, private httpClient: HttpClient, private capBookService: CapBookServicesService) { }

  ngOnInit() {
  }
  public navigateBack():void{
    this.router.navigate(['/welcome'])
  }
  public loginUser(myForm: NgForm):any{
    this.capBookService.loginUser(this.user).subscribe(user1 => {
      this.user = user1;
      if(this.user!=null)
      this.router.navigate(['/homePage',{"userName":this.user.userName}])
    },
    errorMessage=>{
      this.error="Please enter correct Details";
    });
  }

}
