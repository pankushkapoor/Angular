import { Component, OnInit } from '@angular/core';
import { Profile } from '../profile/profileInterface';
import { User } from 'src/app/users/user/userInterface';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { CapBookServicesService } from 'src/app/services/cap-book-services.service';

@Component({
  selector: 'app-albums',
  templateUrl: './albums.component.html',
  styleUrls: ['./albums.component.css']
})
export class AlbumsComponent implements OnInit {
  error: string;
  flag: string='zero';
  profile1:Profile;
  user3: User;
  constructor(private route:ActivatedRoute,private router:Router, private httpClient: HttpClient, private capBookService: CapBookServicesService) { }

  ngOnInit() {
    this.user3 = JSON.parse(localStorage.getItem('user'));
  }
  public goToHome():void{
    this.router.navigate(['/homePage'])
  }

  public viewMessages():void{
    this.router.navigate(['/messages'])
  }

  public viewProfile():void{
    this.router.navigate(['/profile']);
  }

  public viewNotifications():void{
    this.router.navigate(['/Notification'])
  }

  public goToAlbum():void{
    location.reload();
  }
  public logout():void{
    this.capBookService.logout();
  }
}
