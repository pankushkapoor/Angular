import { Component, OnInit } from '@angular/core';
import { User } from 'src/app/users/user/userInterface';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { CapBookServicesService } from 'src/app/services/cap-book-services.service';
import { Profile } from '../profile/profileInterface';

@Component({
  selector: 'app-friend-profile',
  templateUrl: './friend-profile.component.html',
  styleUrls: ['./friend-profile.component.css']
})
export class FriendProfileComponent implements OnInit {
  flag:string='zero';
  error : string;
  constructor(private route:ActivatedRoute,private router:Router, private httpClient: HttpClient, private capBookService: CapBookServicesService) { }
  friendProfile : Profile;
  user : User;
  user3: User;
  ngOnInit() {
    this.friendProfile=JSON.parse(localStorage.getItem('friendProfile'));
    this.user=JSON.parse(localStorage.getItem('user'));
  }
  public addFriend(profile : Profile){
    this.capBookService.addFriend(this.user.emailId,profile.userName).subscribe(tempUser => {
    this.router.navigate(['/homePage']);
     },
    errorMessage=>{
       this.error=errorMessage;
      });
  }
  public goToHome():void{
    if(this.user.profile.name!=null)
    this.router.navigate(['/homePage'])
  }

  public viewProfile():void{
    this.router.navigate(['/profile'])
    
  }
  public viewFriendProfile(profile):void{
    location.reload();
  }
  public viewNotifications():void{
    this.router.navigate(['/Notification'])
  }

  public goToAlbum():void{
    if(this.user.profile.name!=null)
    this.router.navigate(['/albums']);
  }
  public logout():void{
    this.capBookService.logout();
  }
  public viewMessages():void{
    this.router.navigate(['/messages'])
  }
}
