import { Component, OnInit } from '@angular/core';
import { User } from '../users/user/userInterface';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { CapBookServicesService } from '../services/cap-book-services.service';
import { Profile } from 'selenium-webdriver/firefox';

@Component({
  selector: 'app-profiles',
  templateUrl: './profiles.component.html',
  styleUrls: ['./profiles.component.css']
})
export class ProfilesComponent implements OnInit {
  error: string;
  flag: string='zero';
  profile1:Profile;
  user: User = {
    emailId: "",
    password: "",
    profile: {
              name: "",
              gender: "",
              phoneNo: "",
              dateOfBirth: "", 
              bio: "",
              userName: ""
            }
  }
  user3: User;
  constructor(private route:ActivatedRoute,private router:Router, private httpClient: HttpClient, private capBookService: CapBookServicesService) { }

  ngOnInit() {
    //const _user=this.route.snapshot.paramMap.get('emailId');
    this.user3 = JSON.parse(localStorage.getItem('user'));
    this.capBookService.getUserDetails(this.user3.emailId).subscribe(
      user1=>{
      this.user=user1;
    },
    errorMessage=>{
      this.error=errorMessage
    }) ; 
    
    this.capBookService.getProfileDetails(this.user3.profile.userName).subscribe(
      profile1=>{
      this.profile1=profile1;
    },
    errorMessage=>{
      this.error=errorMessage
    }); 
  }
  public goToHome():void{
    if(this.user.profile.name!=null)
    this.router.navigate(['/homePage'])
  }
  public editProfile(){
    this.flag='one';
 //this.router.navigate(['/profile',{"emailId":this.user.profile.emailId}])
 this.router.navigate(['/profile'])
  }

  public viewProfile():void{
    location.reload();
  }
  public viewFriendProfile(profile):void{
    localStorage.setItem('friendProfile',JSON.stringify(profile));
    this.router.navigate(['/friendProfile'])
  }
  public viewNotifications():void{
    this.router.navigate(['/Notification'])
  }

  public goToAlbum():void{
    if(this.user.profile.name!=null)
    this.router.navigate(['/albums']);
  }

  public viewMessages():void{
    this.router.navigate(['/messages'])
  }

  public updateProfile(){
    this.flag='zero';
     this.capBookService.updateProfile(this.user3).subscribe(profile1=>{
      this.user = profile1;
    },
    errorMessage=>{
      this.error = errorMessage;
    });
  }
}
