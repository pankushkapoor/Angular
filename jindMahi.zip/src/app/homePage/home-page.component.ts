import { Component, OnInit } from '@angular/core';
import { User } from '../users/user/userInterface';
import { Profile } from '../profiles/profile/profileInterface';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { CapBookServicesService } from '../services/cap-book-services.service';
import { Post } from '../post/post-interface';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-home-page',
  templateUrl: './home-page.component.html',
  styleUrls: ['./home-page.component.css']
})
export class HomePageComponent implements OnInit {

  pageTitle="Welcome!";
  error: string;
  flag: string='zero';
  flag1: string='zero';
  user: User = {
    emailId: "",
    password: "",
    profile: {
              name: "",
              gender: "",
              phoneNo: "",
              dateOfBirth: "", 
              bio: "",
              userName: ""
            }
  }
  user1: User = {
    emailId: "",
    password: "",
    profile: {
              name: "",
              gender: "",
              phoneNo: "",
              dateOfBirth: "", 
              bio: "",
              userName: ""
            }
  }
  profileList: Profile[];
  post: Post = {
    postId:0,
    postContent:""
  }
  postList:string[];
  user3:User;
  constructor(private route:ActivatedRoute,private router:Router, private httpClient: HttpClient, private capBookService: CapBookServicesService) { }

  ngOnInit() {
    this.user3 = JSON.parse(localStorage.getItem('user'));
    // const _user=this.route.snapshot.paramMap.get('emailId');
    this.capBookService.getUserDetails(this.user3.emailId).subscribe(
      user=>{
      this.user=user;
    },
    errorMessage=>{
      this.error=errorMessage;
    })    
    
    this.capBookService.getMyPosts(this.user3.emailId).subscribe(
      posts =>{
        this.postList=posts;
        this.postList=this.postList.reverse();
      }
    )
    this.capBookService.getAllPosts(this.user3.emailId).subscribe(
      posts =>{
        posts.forEach(element => {
          this.postList.push(element)
        });
        
        this.postList=this.postList.reverse();
      }
    )
    this.capBookService.getProfileDetails(this.user3.profile.userName).subscribe(
      profile1=>{
      this.user.profile=profile1;
    },
    errorMessage=>{
      this.error=errorMessage;
    }) 
    localStorage.getItem('user');
    
  }
  public logout():void{
    this.capBookService.logout();
  }
  public getName(post:string):string{
    return post.substr(0,post.indexOf('-'))
   }
   public getMessage(post:string):string{
     return post.substr(post.indexOf('-')+1,post.length)
   }
   public exit() {
    location.reload();
  }
  public viewProfile():void{
    if(this.user.profile.name!=null)
    this.router.navigate(['/profile'])
  }
  public viewFriendProfile(profile):void{
    localStorage.setItem('friendProfile',JSON.stringify(profile));
    this.router.navigate(['/friendProfile'])
  }
  public viewNotifications():void{
    this.router.navigate(['/Notification',{"emailId":this.user.emailId}])
  }
  public goToHome():void{
    if(this.user.profile.name!=null)
    this.router.navigate(['/homePage',{"emailId":this.user.profile.userName}])
  }

  public viewMessages():void{
    this.router.navigate(['/messages'])
  }

  public goToAlbum():void{
    if(this.user.profile.name!=null)
    this.router.navigate(['/albums']);
  }
  public closeShowUsers():void{
    this.flag1="one";
    this.router.navigate(['/homePage']);
  }
/*   public addPost():void{
    this.capBookService.addPost(this.post).subscribe(post => {
    this.post = post;
    this.router.navigate(['/homePage'])
      
     },
     errorMessage=>{
    this.error="Post not added";
     }); */
//  }
public addPost(myForm: NgForm):any{
  this.capBookService.addPost(this.post, this.user.emailId).subscribe(post => {
  this.post = post;
  this.exit();
   // this.router.navigate(['/homePage',{'emailId': this.user.emailId}])
 },
errorMessage=>{
   this.error=errorMessage;
  });
}
public addFriend(profile : Profile){
  this.capBookService.addFriend(this.user.emailId,profile.userName).subscribe(tempUser => {
  
    this.exit();
   },
  errorMessage=>{
     this.error=errorMessage;
    });
}

  public searchFriend():any{
    if(this.user1.profile.name!=''){
      this.capBookService.searchFriend(this.user1.profile.name).subscribe(profileList1 => {
        this.profileList = profileList1;
        if(this.profileList.length!=0){
          this.flag1="zero";
          this.flag='zero';
          this.router.navigate(['/homePage'])
        }
        else{
          this.flag='one';
          this.error="No user with this name";
        }
      },
      errorMessage=>{
        // this.flag='one';
        //this.error="No user with this name";
      });
    }
  }

}
