import { Component, OnInit } from '@angular/core';
import { User } from '../users/user/userInterface';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { CapBookServicesService } from '../services/cap-book-services.service';

@Component({
  selector: 'app-notification',
  templateUrl: './notification.component.html',
  styleUrls: ['./notification.component.css']
})
export class NotificationComponent implements OnInit {

  constructor(private route:ActivatedRoute,private router:Router, private httpClient: HttpClient, private capBookService: CapBookServicesService) { }

  user: User = {
    emailId: "",
    password: "",
    profile: {
              name: "",
              gender: "",
              phoneNo: "",
              dateOfBirth: "", 
              bio: "",
              userName: ""
            }
  }
  error : string;
  notifications:string[]

  ngOnInit() {
    const _user=this.route.snapshot.paramMap.get('emailId');
    this.capBookService.getUserDetails(_user).subscribe(
      user=>{
      this.user=user;
    },
    errorMessage=>{
      this.error=errorMessage;
    })  

    this.capBookService.getAllNotifications(_user.toString()).subscribe(
      notifications=>{
      this.notifications=notifications;
    },
    errorMessage=>{
      this.error=errorMessage;
    })
  }
  public goToHome():void{
    this.router.navigate(['/homePage'])
  }

  public viewProfile():void{
    this.router.navigate(['/profile']);
  }

  public viewNotifications():void{
    location.reload();
  }

  public goToAlbum():void{
    this.router.navigate(['/albums']);
  }
  public logout():void{
    this.capBookService.logout();
  }

  public viewMessages():void{
    this.router.navigate(['/messages'])
  }
}
