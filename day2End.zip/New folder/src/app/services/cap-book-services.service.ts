import { Injectable } from '@angular/core';
import { User } from '../users/user/userInterface';
import { Profile } from '../profiles/profile/profileInterface';
import { HttpClient, HttpHeaders, HttpErrorResponse, HttpParams } from '@angular/common/http';
import {map,catchError} from 'rxjs/operators'
import { throwError, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CapBookServicesService {

  user: User;
  profile: Profile;
  private headers = new HttpHeaders({'Content-Type': 'application/json'});
  constructor(private httpClient:HttpClient) { }
  
  public signUpUser(user: User):any{
    return this.httpClient.post<User>("http://localhost:5558/acceptUserDetails",user, {headers: this.headers}).pipe(catchError(this.handleError));

  }
  public loginUser(user: User):any{
    return this.httpClient.post<User>("http://localhost:5558/loginUser",user, {headers: this.headers}).pipe(catchError(this.handleError));

  }
  
  public getUserDetails(userName:string):any{
    let params=new HttpParams();
    params=params.set('userName',userName.toString());
    return this.httpClient.get<User>("http://localhost:5558/getUserDetails",{params:params}).pipe(catchError(this.handleError));

  }
  public getProfileDetails(emailId:string):any{
    let params=new HttpParams();
    params=params.set('emailId',emailId.toString());
    return this.httpClient.get<Profile>("http://localhost:5558/getProfileDetails",{params:params}).pipe(catchError(this.handleError));

  }
  public searchFriend(name:string):any{
    let params=new HttpParams();
    params=params.set('name',name.toString());
    return this.httpClient.get<Profile[]>("http://localhost:5558/searchFriend",{params:params}).pipe(catchError(this.handleError));

  }
  public updateProfile(user:User):Observable<User>{      
    return  this.httpClient.post<User>("http://localhost:5558/updateUserDetails",user,{headers: this.headers}).pipe(catchError(this.handleError));
  } 

  private handleError(error:any){
    if(error instanceof ErrorEvent){
      console.error('1 An ErrorEvent occurred:',error.error.message);
      return throwError(error.error.message);
    }else if(error instanceof HttpErrorResponse ){
      console.error(`2 Backend returned code ${error.status},body was: ${error.message}`);
      return throwError(`Backend returned code ${error.status},body was: ${error.message}`);
    }
    else if(error instanceof TypeError){
      console.error(`3 TypeError has occured ${error.message}, body was ${error.stack}`)
      return throwError(`TypeError has occured ${error.message}, body was ${error.stack}`)
    }
  }
}
