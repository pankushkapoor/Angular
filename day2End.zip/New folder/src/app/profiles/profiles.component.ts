import { Component, OnInit } from '@angular/core';
import { User } from '../users/user/userInterface';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { CapBookServicesService } from '../services/cap-book-services.service';

@Component({
  selector: 'app-profiles',
  templateUrl: './profiles.component.html',
  styleUrls: ['./profiles.component.css']
})
export class ProfilesComponent implements OnInit {
  error: string;
  flag: string='zero';
  user: User = {
    userName: "",
    password: "",
    profile: {
              name: "",
              gender: "",
              phoneNo: "",
              dateOfBirth: "", 
              bio: "",
              emailId: ""
            }
  }
  constructor(private route:ActivatedRoute,private router:Router, private httpClient: HttpClient, private capBookService: CapBookServicesService) { }

  ngOnInit() {
    const _user=this.route.snapshot.paramMap.get('userName');
    this.capBookService.getUserDetails(_user).subscribe(
      user1=>{
      this.user=user1;
    },
    errorMessage=>{
      this.error=errorMessage
    }) ;   
  }
  public goToHome():void{
    if(this.user.profile.name!=null)
    this.router.navigate(['/homePage',{"emailId":this.user.profile.emailId}])
  }
  public editProfile(){
    this.flag='one';
 //this.router.navigate(['/profile',{"emailId":this.user.profile.emailId}])
 this.router.navigate(['/profile'])
  }

  public updateProfile(){
    this.flag='zero';
     this.capBookService.updateProfile(this.user).subscribe(profile1=>{
      this.user = profile1;
    },
    errorMessage=>{
      this.error = errorMessage;
    });
  }
}
