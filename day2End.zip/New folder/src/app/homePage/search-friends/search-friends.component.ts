import { Component, OnInit } from '@angular/core';
import { User } from 'src/app/users/user/userInterface';
import { Profile } from 'src/app/profiles/profile/profileInterface';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { CapBookServicesService } from 'src/app/services/cap-book-services.service';

@Component({
  selector: 'app-search-friends',
  templateUrl: './search-friends.component.html',
  styleUrls: ['./search-friends.component.css']
})
export class SearchFriendsComponent implements OnInit {

  searchBox:string="Search Friend";
  // user: User;
  // profile: Profile;
  profileList: Profile[];
  error: string;
  user: User = {
    userName: "",
    password: "",
    profile: {
              name: "",
              gender: "",
              phoneNo: "",
              dateOfBirth: "", 
              bio: "",
              emailId: ""
            }
  }
  constructor(private route:ActivatedRoute,private router:Router, private httpClient: HttpClient, private capBookService: CapBookServicesService) { }

  
  ngOnInit() {
  }

  // public navigateBack():void{
  //   this.router.navigate(['/welcome'])
  // }
  public searchFriend():any{
    this.capBookService.searchFriend(this.user.profile.name).subscribe(profileList1 => {
      this.profileList = profileList1;
      if(this.profileList!=null)
      this.router.navigate(['/searchFriend'])
    },
    errorMessage=>{
      this.error="No user with this name";
    });
  }

}
