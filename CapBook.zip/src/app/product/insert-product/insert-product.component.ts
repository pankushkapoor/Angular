import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ProductService } from 'src/app/services1/product.service';
import { Product } from 'src/app/products/product';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { NgForm } from '@angular/forms';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-insert-product',
  templateUrl: './insert-product.component.html',
  styleUrls: ['./insert-product.component.css']
})
export class InsertProductComponent implements OnInit {

  constructor(private route:ActivatedRoute,private router:Router,private productService:ProductService, private httpClient: HttpClient) { }
  pageTitle:string="Insert Product Information";
  _productId:number=0;
  _productName:string='';
  _productCode:string='';
  _releaseDate:string='';
  _description:string='';
  _price:number=0;
  _starRating:number=0;
  error:string;

  product: Product = {productId:0, productName:'', productCode:'', price:0, starRating:0, releaseDate:'', description:''};

  get productId():number{
    return this._productId;
  }
  set productId(value:number){
    this._productId=value;
  }
 
  get productName():string{
    return this._productName;
  }
  set productName(value:string){
    this._productName=value;
  }
 
  get productCode():string{
    return this._productCode;
  }
  set productCode(value:string){
    this._productCode=value;
  }
 
  get releaseDate():string{
    return this._releaseDate;
  }
  set releaseDate(value:string){
    this._releaseDate=value;
  }
 
  get description():string{
    return this._description;
  }
  set description(value:string){
    this._description=value;
  }
 
  get price():number{
    return this._price;
  }
  set price(value:number){
    this._price=value;
  }
 
  get starRating():number{
    return this._starRating;
  }
  set starRating(value:number){
    this._starRating=value;
  }
  ngOnInit() {
    //this.productService.submitProduct(this.product).subscribe
  }
  // products: Observable<Product[]>
  // productList: Product[];
  // mappedList: Product[] = []
  // DemoProduct: Product;

  // public getDemoObject(myForm: NgForm): any{
  //   this.DemoProduct = new Product; 
  // }

  public navigateBack():void{
    this.router.navigate(['/products'])
  }
  public submitProduct(myForm: NgForm):any{
    
    this.productService.submitProduct(this.product).subscribe(product1 => {
      this.product = product1;
    },
    errorMessage=>{
      this.error=errorMessage;
    });
    this.router.navigate(['/products'])
  }
}
