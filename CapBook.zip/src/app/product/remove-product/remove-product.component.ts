import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Product } from 'src/app/products/product';
import { ProductService } from 'src/app/services1/product.service';

@Component({
  selector: 'app-remove-product',
  templateUrl: './remove-product.component.html',
  styleUrls: ['./remove-product.component.css']
})
export class RemoveProductComponent implements OnInit {
  pageTitle:string='Product Detail';
  errorMessage:string;
  product:Product;
  constructor(private route:ActivatedRoute,private router:Router,private productService:ProductService) { }

  ngOnInit() {
    const id=this.route.snapshot.paramMap.get('id');
    const productId= +id;
    this.productService.removeProductDetails(productId).subscribe(
      product=>{
      this.product=null;
    },
    errorMessage=>{
      this.errorMessage=errorMessage;
    })    
  }
}