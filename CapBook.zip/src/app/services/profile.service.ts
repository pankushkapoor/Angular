import { Injectable } from '@angular/core';
import { HttpClient } from 'selenium-webdriver/http';
import { HttpHeaders } from '@angular/common/http';
import { Profile } from 'selenium-webdriver/firefox';

@Injectable({
  providedIn: 'root'
})
export class ProfileService {

  profile : Profile;
  private headers = new HttpHeaders({'Content-Type': 'application/json'});
  
  constructor(private httpClient:HttpClient) { }

  
}
