import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { User } from '../user/users/users';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  private productDataUrl:string='productsData/productsList.json';
  user: User;
  private headers = new HttpHeaders({'Content-Type': 'application/json'});
  constructor(private httpClient:HttpClient){}

  public getAllProductsDetails():Observable<User[]>{
    //return this.httpClient.get<Product[]>(this.productDataUrl).pipe(catchError(this.handleError));
    return this.httpClient.get<User[]>("http://localhost:8008/project/allProductDetails").pipe(catchError(this.handleError));
  }
  
  private handleError(error:any){
    if(error instanceof ErrorEvent){
      console.error('1 An ErrorEvent occurred:',error.error.message);
      return throwError(error.error.message);
    }else if(error instanceof HttpErrorResponse ){
      console.error(`2 Backend returned code ${error.status},body was: ${error.message}`);
      return throwError(`Backend returned code ${error.status},body was: ${error.message}`);
    }
    else if(error instanceof TypeError){
      console.error(`3 TypeError has occured ${error.message}, body was ${error.stack}`)
      return throwError(`TypeError has occured ${error.message}, body was ${error.stack}`)
    }
  }
}
