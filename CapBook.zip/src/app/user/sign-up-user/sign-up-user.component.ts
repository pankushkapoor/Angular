import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ProfileService } from 'src/app/services/profile.service';
import { HttpClient } from 'selenium-webdriver/http';
import { User } from '../users/users';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-sign-up-user',
  templateUrl: './sign-up-user.component.html',
  styleUrls: ['./sign-up-user.component.css']
})
export class SignUpUserComponent implements OnInit {

  constructor(private route:ActivatedRoute,private router:Router,private profileService:ProfileService, private httpClient: HttpClient) { }
  pageTitle:string="Enter Information";
  _userName: string='';
  _password: string='';
  _emailId: string='';
  _dateOfBirth: string='';
  _gender: string='';
  _phoneNo: string='';
  error: string;
  
  user: User = {userName:'', password:'', emailId:'', dateOfBirth:'', gender:'', phoneNo:''};

  get userName():string{
    return this._userName;
  }
  set userName(value:string){
    this._userName=value;
  }
  get password():string{
    return this._password;
  }
  set password(value:string){
    this._password=value;
  }
  get emailId():string{
    return this._emailId;
  }
  set emailId(value:string){
    this._emailId=value;
  }
  get dateOfBirth():string{
    return this._dateOfBirth;
  }
  set dateOfBirth(value:string){
    this._dateOfBirth=value;
  }
  get gender():string{
    return this._gender;
  }
  set gender(value:string){
    this._gender=value;
  }
  get phoneNo():string{
    return this._phoneNo;
  }
  set phoneNo(value:string){
    this._phoneNo=value;
  }

  ngOnInit() {
  }

  public navigateBack():void{
    this.router.navigate(['/index'])
  }
  public signUpUser(myForm: NgForm):any{
    
  //   this.User.submitProduct(this.product).subscribe(product1 => {
  //     this.product = product1;
  //   },
  //   errorMessage=>{
  //     this.error=errorMessage;
  //   });
  //   this.router.navigate(['/products'])
   }
}
