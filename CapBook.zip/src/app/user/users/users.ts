export interface User {
    userName: string;
    password: string;
    emailId: string;
    dateOfBirth: string;
    gender: string;
    phoneNo: string;
}
