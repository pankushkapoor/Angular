import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {FormsModule} from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';
import { WelcomeComponent } from './welcome/welcome.component';
import { RouterModule } from '@angular/router';
import { ProfileComponent } from './profile/profile.component';
import { UserComponent } from './user/user.component';
import { LoginUserComponent } from './user/login-user/login-user.component';
import { SignUpUserComponent } from './user/sign-up-user/sign-up-user.component';
import { ProfileService } from './services/profile.service';
import { UserService } from './services/user.service';
@NgModule({
  declarations: [
    AppComponent,
    WelcomeComponent,
    ProfileComponent,
    UserComponent,
    LoginUserComponent,
    SignUpUserComponent,
 
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot([
      // { path:'products',component: ProductlistComponent},
      { path: 'welcome',component:  WelcomeComponent},
      // { path: 'product/:id',component:ProductdetailsComponent},
      // { path: 'remove/:id',component:RemoveProductComponent},
      //{ path: 'search' ,component:SearchComponent},
      // { path: 'insert' ,component:InsertProductComponent},
      { path: '',redirectTo:'welcome',pathMatch:'full'},
    ])
  ],
  providers: [ProfileService, UserService],
  bootstrap: [AppComponent]
})
export class AppModule { }
