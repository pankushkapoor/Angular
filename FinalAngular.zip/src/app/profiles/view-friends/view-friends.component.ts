import { Component, OnInit } from '@angular/core';
import { User } from 'src/app/users/user/userInterface';
import { Profile } from '../profile/profileInterface';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { CapBookServicesService } from 'src/app/services/cap-book-services.service';

@Component({
  selector: 'app-view-friends',
  templateUrl: './view-friends.component.html',
  styleUrls: ['./view-friends.component.css']
})
export class ViewFriendsComponent implements OnInit {

  constructor(private route:ActivatedRoute,private router:Router, private httpClient: HttpClient, private capBookService: CapBookServicesService) { }

  error : string;
  friendProfiles : Profile[];
  user: User = {
    emailId: "",
    password: "",
    profile: {
              name: "",
              gender: "",
              phoneNo: "",
              dateOfBirth: "", 
              bio: "",
              userName: ""
            },
    securityQuestion: ""
  }
  ngOnInit() {
    this.user = JSON.parse(localStorage.getItem('user'));

    this.capBookService.getAllFriends(this.user.emailId).subscribe(
      friends =>{
        this.friendProfiles=friends;
      }
    ) 

  }

}
  
