import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { CapBookServicesService } from 'src/app/services/cap-book-services.service';
import { User } from '../user/userInterface';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-login-user',
  templateUrl: './login-user.component.html',
  styleUrls: ['./login-user.component.css']
})
export class LoginUserComponent implements OnInit {

  pageTitle="Enter Details";
  error: string;
  user: User = {
    emailId: "",
    password: "",
    profile: {
              name: "",
              gender: "",
              phoneNo: "",
              dateOfBirth: "", 
              bio: "",
              userName: "",
            },
    securityQuestion: ""
  }
  user1: User = {
    emailId: "",
    password: "",
    profile: {
              name: "",
              gender: "",
              phoneNo: "",
              dateOfBirth: "", 
              bio: "",
              userName: "",
            },
    securityQuestion: ""
  }
  user2: User = {
    emailId: "",
    password: "",
    profile: {
              name: "",
              gender: "",
              phoneNo: "",
              dateOfBirth: "", 
              bio: "",
              userName: "",
            },
    securityQuestion: ""
  }
  forgotFlag: string ='false';
  authorizeFlag='false';
  constructor(private route:ActivatedRoute,private router:Router, private httpClient: HttpClient, private capBookService: CapBookServicesService) { }

  ngOnInit() {
   if(localStorage.getItem('isLoggedIn')=='true'){
    location.replace('http://localhost:4200/homePage')
  }
  }
  public forgotPassword():void{
    this.forgotFlag='true';
  }
  public authorizeQuestion():void{
    this.authorizeFlag = 'true';
  }
  public loginUser(myForm: NgForm):any{
    this.capBookService.loginUser(this.user).subscribe(user1 => {
      this.user2 = user1;
      // console.log(localStorage.getItem('isLoggedIn'));
      if(this.user2!=null){
      this.capBookService.logout();
      localStorage.setItem('isLoggedIn', 'true');
      localStorage.setItem('user', JSON.stringify(user1));
      console.log(localStorage.getItem('isLoggedIn'))
      this.router.navigate(['/homePage']);
      }
      else{
          this.error="error";
          console.log(localStorage.getItem('isLoggedIn'))
          // location.reload();
        // this.router.navigate(['/login']);
      }
    },
    errorMessage=>{
      this.error=errorMessage;
    });
  }
}
