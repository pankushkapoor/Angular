import { Profile } from "src/app/profiles/profile/profileInterface";

export interface User{
    emailId: string;
    password: string;
    profile: Profile;
    securityQuestion: string;
}