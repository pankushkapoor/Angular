import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient, HttpErrorResponse, HttpParams, HttpHeaders } from '@angular/common/http';
import { NgForm } from '@angular/forms';
import { CapBookServicesService } from 'src/app/services/cap-book-services.service';
import { User } from '../user/userInterface';
import { Profile } from 'src/app/profiles/profile/profileInterface';

@Component({
  selector: 'app-sign-up-user',
  templateUrl: './sign-up-user.component.html',
  styleUrls: ['./sign-up-user.component.css']
})
export class SignUpUserComponent implements OnInit {
  pageTitle="Enter Details";
  error: string;
  constructor(private route:ActivatedRoute,private router:Router, private httpClient: HttpClient, private capBookService: CapBookServicesService) { }

   user: User = {
    emailId: "",
    password: "",
    profile: {
              name: "",
              gender: "",
              phoneNo: "",
              dateOfBirth: "", 
              bio: "",
              userName: "",
            },
    securityQuestion: ""
  }

  ngOnInit() {
  }
  public navigateBack():void{
    this.router.navigate(['/login'])
  }
  public signUpUser(myForm: NgForm):any{
    this.capBookService.signUpUser(this.user).subscribe(user1 => {
      this.user = user1;
      if(this.user!=null){
      localStorage.setItem('isLoggedIn', 'true');
      localStorage.setItem('user', JSON.stringify(user1));
      console.log(localStorage.getItem('isLoggedIn'))
      this.router.navigate(['/homePage']);
      }
      else{
        this.error="error";
      }
    }    
    );
  }
}

 