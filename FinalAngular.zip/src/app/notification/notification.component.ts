import { Component, OnInit } from '@angular/core';
import { User } from '../users/user/userInterface';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { CapBookServicesService } from '../services/cap-book-services.service';

@Component({
  selector: 'app-notification',
  templateUrl: './notification.component.html',
  styleUrls: ['./notification.component.css']
})
export class NotificationComponent implements OnInit {

  constructor(private route:ActivatedRoute,private router:Router, private httpClient: HttpClient, private capBookService: CapBookServicesService) { }

  user: User = {
    emailId: "",
    password: "",
    profile: {
              name: "",
              gender: "",
              phoneNo: "",
              dateOfBirth: "", 
              bio: "",
              userName: "",
            },
    securityQuestion: ""
  }

  user2: User = {
    emailId: "",
    password: "",
    profile: {
              name: "",
              gender: "",
              phoneNo: "",
              dateOfBirth: "", 
              bio: "",
              userName: "",
            },
    securityQuestion: ""
  }
  
  error : string;
  notifications:Notification[]
  emailId : string;
  name : string; 
  note:Notification;

  ngOnInit() {
    this.user = JSON.parse(localStorage.getItem('user'));

    this.capBookService.getAllNotifications(this.user.emailId).subscribe(
      notes =>{
        this.notifications=notes;
      }
    )
  }
  public addFriend(emailId:string,userName:string,id:number){
    
   this.capBookService.addFriend(emailId,userName).subscribe(
     user=>{
       this.user=user
     }
   );
   this.removeNotification(id);
   location.reload();
     }

  public removeNotification(id:number){
    console.log("later inside notification value is "+id)
    this.capBookService.removeNotification(id).subscribe(
      no=>{
        
        this.note=no
      }
    );
   location.reload();
  }

  public goToHome():void{
    this.router.navigate(['/homePage'])
  }

  public viewProfile():void{
    this.router.navigate(['/profile']);
  }

  public viewNotifications():void{
    location.reload();
  }

  public goToAlbum():void{
    this.router.navigate(['/albums']);
  }
  public logout():void{
    this.capBookService.logout();
  }

  public viewMessages():void{
    this.router.navigate(['/messages'])
  }
}
