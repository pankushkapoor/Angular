export interface Post {
    postId: number;
    postContent: string;
}
